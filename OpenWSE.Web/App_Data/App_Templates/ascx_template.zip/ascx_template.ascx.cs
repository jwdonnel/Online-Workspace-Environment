﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OpenWSE_Tools.Apps;

public partial class ascx_template : System.Web.UI.UserControl {

    #region private variables

    private readonly ServerSettings _ss = new ServerSettings();
    private AppInitializer _appInitializer;
    private const string app_id = "REPLACE WITH APP ID";

    #endregion

    protected void Page_Load(object sender, EventArgs e) {
        App _apps = new App(string.Empty);
        string cl = _apps.GetAppName(app_id);
        lbl_Title.Text = cl;

        if (!_ss.HideAllAppIcons) {
            img_Title.Visible = true;
            string clImg = _apps.GetAppIconName(app_id);
            img_Title.ImageUrl = "~/Standard_Images/App_Icons/" + clImg;
        }
        else {
            img_Title.Visible = false;
        }

        _appInitializer = new AppInitializer(app_id, Page.User.Identity.Name, Page);
        _appInitializer.LoadScripts_JS(true);
        _appInitializer.LoadScripts_CSS();
    }
}