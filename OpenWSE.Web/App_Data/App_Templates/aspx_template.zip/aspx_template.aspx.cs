﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OpenWSE_Tools.Apps;

public partial class aspx_template : System.Web.UI.Page {

    #region Private Variables

    private readonly ServerSettings _ss = new ServerSettings();
    private AppInitializer _appInitializer;
    private const string app_id = "REPLACE WITH APP ID";
    private string _siteTheme = "Standard";

    #endregion

    protected void Page_Load(object sender, EventArgs e) {
        _appInitializer = new AppInitializer(app_id, Page.User.Identity.Name, Page);
        if (_appInitializer.TryLoadPageEvent) {
            _siteTheme = _appInitializer.siteTheme;

            if (!IsPostBack) {
                // Initialize all the scripts and style sheets
                _appInitializer.SetHeaderLabelImage(lbl_Title, img_Title);
                _appInitializer.LoadScripts_JS(false);
                _appInitializer.LoadScripts_CSS();
            }
        }
    }

}