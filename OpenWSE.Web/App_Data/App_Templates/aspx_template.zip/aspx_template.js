// Place all your javascript code here

function pageLoad() {
}